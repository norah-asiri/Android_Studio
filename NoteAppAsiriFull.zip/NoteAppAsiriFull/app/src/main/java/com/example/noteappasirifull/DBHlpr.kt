package com.example.noteappasirifull

import android.annotation.SuppressLint
import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteException
import android.database.sqlite.SQLiteOpenHelper



// https://developer.android.com/reference/kotlin/android/database/sqlite/SQLiteDatabase
// https://www.codevoila.com/post/47/android-tutorial-sqlite-database


class DBHlpr (context: Context): SQLiteOpenHelper(
    context,
    DATABASE_NAME,
    null,
    DATABASE_VERSION){

    // to set valve for db
    companion object{
        private const val DATABASE_VERSION = 1
        private const val DATABASE_NAME = "MyDB"
        private const val TABLE_NOTES = "NotesTable"

        private const val KEY_ID = "_id"
        private const val KEY_NOTE = "note"
    }

    //create table by use sql "CREATE TABLE"
    override fun onCreate(db: SQLiteDatabase?) {

        //val createTable =("CREATE TABLE table_name (column_name2 type PRIMARY KEY, $column_name2 type)")
        // if column is primary put after name: PRIMARY KEY
        val createTable = ("CREATE TABLE $TABLE_NOTES($KEY_ID INTEGER PRIMARY KEY, $KEY_NOTE TEXT)")

        db?.execSQL(createTable) // execute sql expiration
    }

    override fun onUpgrade(db: SQLiteDatabase?, p1: Int, p2: Int) { //db: SQLiteDatabase?, oldVersion: Int, newVersion: Int
        db!!.execSQL("DROP TABLE IF EXISTS $TABLE_NOTES") // drop old database
        onCreate(db) // create new Version of database
    }

    // add new Note
    fun addNote(note: NoteModel): Long{
        val db = this.writableDatabase //create writable Database
        val contentValues = ContentValues() // create contentValues
        contentValues.put(KEY_NOTE, note.noteText) // set value in db (add record to table)

        val success = db.insert(TABLE_NOTES, null, contentValues)
        db.close()  // close database

        return success // return status : -1 or row
        // -1 = did not save data
        // row_number  = data it save successfully
    }

    // retrieve all Notes
    @SuppressLint("Range")
    fun viewNotes(): ArrayList<NoteModel>{
        val noteList: ArrayList<NoteModel> = ArrayList()
        // array list to save all rows value, each row values get it as object of not, contain id and notes

        val selectQuery = "SELECT * FROM $TABLE_NOTES" // select all columns values from table

        val db = this.readableDatabase // return readable copy of db
        var cursor: Cursor? = null

        try {
            cursor = db.rawQuery(selectQuery, null)// get each row
        } catch (e: SQLiteException){
            db.execSQL(selectQuery) // use execSQL() in catch because execSQL() method has no return value. then return list
            return ArrayList()
        }

        var id: Int
        var noteText: String


        // moveToFirst(): it moves the cursor to the first result (when the set is not empty).
        if(cursor.moveToFirst()){
            do {
                id = cursor.getInt(cursor.getColumnIndex(KEY_ID)) // get id
                noteText = cursor.getString(cursor.getColumnIndex(KEY_NOTE)) // get note
                val note = NoteModel(id = id, noteText = noteText) // make object of NoteModel then set id and note value
                noteList.add(note) // add the note object to list
            } while (cursor.moveToNext())// moveToNext() It allows you to test whether the query returned an empty set.
        }

        return noteList // return list of note
    }
    fun updateNote(note: NoteModel): Int {
        val db = this.writableDatabase
        val contentValues = ContentValues()
        contentValues.put(KEY_NOTE, note.noteText)

        val success = db.update(TABLE_NOTES, contentValues, "$KEY_ID = ${note.id}", null)

        db.close()
        return success
    }

    fun deleteNote(note: NoteModel): Int{
        val db = this.writableDatabase
        val contentValues = ContentValues()
        contentValues.put(KEY_ID, note.id)
        val success = db.delete(TABLE_NOTES, "$KEY_ID = ${note.id}", null)
        db.close()
        return success
//        success > 0 means it worked
    }
}