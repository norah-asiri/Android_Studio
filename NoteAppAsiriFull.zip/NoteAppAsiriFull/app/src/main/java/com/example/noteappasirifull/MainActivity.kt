package com.example.noteappasirifull

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlinx.android.synthetic.main.activity_main.*
import android.content.DialogInterface
import androidx.appcompat.app.AlertDialog


class MainActivity : AppCompatActivity() {

    private lateinit var db: DBHlpr
    private lateinit var edNote: EditText
    private lateinit var btnSave: Button
    private  lateinit var rvNotes : RecyclerView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        db = DBHlpr(this)

        edNote = findViewById(R.id.etNote)
        rvNotes = findViewById(R.id.recyclerView)
        btnSave = findViewById(R.id.Save)



        btnSave.setOnClickListener {postNote()}
        updateRV()
    }

    // update RV to show new notes
    private fun updateRV(){
        rvNotes.adapter = NoteAdapter(this, getItemsList())
        rvNotes.layoutManager = LinearLayoutManager(this)
    }

    // get list of notes
    private fun getItemsList(): ArrayList<NoteModel>{
        return db.viewNotes() }

    // add note
    private fun postNote(){
        db.addNote(NoteModel(0, etNote.text.toString()))
        etNote.text.clear()
        Toast.makeText(this, "Note Added", Toast.LENGTH_LONG).show()
        updateRV()
    }

    // edit Note
    private fun editNote(noteID: Int, noteText: String){
        db.updateNote(NoteModel(noteID, noteText))
        updateRV()
    }

    // delete Note
    private fun del(noteID: Int){
        db.deleteNote(NoteModel(noteID, ""))
        updateRV()
    }

    //confirmation alert
    fun deleteNote(noteID: Int){
        val dialogBuilder = AlertDialog.Builder(this)
        dialogBuilder
            .setCancelable(false)
            .setPositiveButton("Yes", DialogInterface.OnClickListener {
                    _, _ -> del(noteID)
            })
            .setNegativeButton("Cancel", DialogInterface.OnClickListener {
                    dialog, _ -> dialog.cancel()
            })
        val alert = dialogBuilder.create()
        alert.setTitle("Are you sure?")
        alert.show()
    }

    fun raiseDialog(id: Int){
        val dialogBuilder = AlertDialog.Builder(this)
        val updatedNote = EditText(this)
        updatedNote.hint = "Enter new text"
        dialogBuilder
            .setCancelable(false)
            .setPositiveButton("Save", DialogInterface.OnClickListener {
                    _, _ -> editNote(id, updatedNote.text.toString())
            })
            .setNegativeButton("Cancel", DialogInterface.OnClickListener {
                    dialog, _ -> dialog.cancel()
            })
        val alert = dialogBuilder.create()
        alert.setTitle("Update Note")
        alert.setView(updatedNote)
        alert.show()
    }
}
