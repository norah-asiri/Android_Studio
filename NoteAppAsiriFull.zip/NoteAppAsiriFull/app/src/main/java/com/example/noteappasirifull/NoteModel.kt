package com.example.noteappasirifull

data class NoteModel(val id: Int, val noteText: String)

