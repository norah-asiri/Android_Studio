package com.example.ready

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast

class MainActivity : AppCompatActivity() {
    lateinit var text1 : EditText
    lateinit var text2 : EditText
    lateinit var botton1 : Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
         text1=findViewById(R.id.utext1)
        text2=findViewById(R.id.utext2)
        botton1=findViewById(R.id.button)
        botton1.setOnClickListener {
            var name = text1.text.toString()
                name  =name +" "+ text2.text.toString()
            Toast.makeText(applicationContext,"$name",Toast.LENGTH_SHORT).show()
        }
    }
}