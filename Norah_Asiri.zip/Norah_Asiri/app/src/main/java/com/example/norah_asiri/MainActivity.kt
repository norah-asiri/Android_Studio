package com.example.norah_asiri

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast

lateinit var print_b : Button
lateinit var next_b : Button
lateinit var toast_b : Button
lateinit var name_u : EditText
lateinit var mobile_u : EditText
lateinit var location_use : EditText
lateinit var print_user_info: TextView


class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        toast_b = findViewById(R.id.button)
        print_b = findViewById(R.id.button2)
        next_b = findViewById(R.id.button3)
        name_u = findViewById(R.id.Name)
        location_use = findViewById(R.id.Location)
        mobile_u = findViewById(R.id.Number)
        print_user_info = findViewById(R.id.print_user_info)


        next_b.setOnClickListener {
            val intent = Intent(this, A_2::class.java)
            intent.putExtra("uName", name_u.text.toString())
            intent.putExtra("uMobile", mobile_u.text.toString())
            intent.putExtra("uLoc", location_use.text.toString())
            startActivity(intent)

        }
        var information = listOf(name_u.text,location_use.text,mobile_u.text)
        toast_b.setOnClickListener {
            Toast.makeText(this@MainActivity, information.shuffled().toString(), Toast.LENGTH_SHORT).show()
            //Toast.makeText(this@MainActivity,name_u.text.toString(),Toast.LENGTH_SHORT).show()
            //Toast.makeText(this@MainActivity, "${name_u.text} ${mobile_u.text} ${location_use.text}", Toast.LENGTH_SHORT).show()

        }



        print_b.setOnClickListener {
            print_user_info.text = name_u.text.toString() + "\n" + mobile_u.text.toString() + "\n" + location_use.text.toString()
        }


        }
    }