package com.example.norah_asiri

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView

class A_2 : AppCompatActivity() {

    lateinit var info : TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_a2)

        val st1=intent.getStringExtra("uName")
        val st2=intent.getStringExtra("uMobile")
        val st3=intent.getStringExtra("uLoc")
        info=findViewById(R.id.textView2)
        info.text=st1.toString()+" "+st2.toString()+" "+st3.toString()


    }
}