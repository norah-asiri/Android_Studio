package com.example.asiri_norah_recycler_view_app

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.snackbar.Snackbar

class MainActivity : AppCompatActivity() {


    lateinit var etUsertext: EditText // text box to enter some text
    lateinit var btenter: Button // button enter
    lateinit var listOfText: ArrayList<String> // to hold texts
    lateinit var myRV: RecyclerView // to see all data on one screen

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        myRV = findViewById(R.id.rvMain) // connect myRV with recycler view ui
        listOfText = ArrayList() // to initialize our list

        listOfText.add("1")
        listOfText.add("1")
        listOfText.add("1")
        listOfText.add("1")
        listOfText.add("1")
        listOfText.add("1")
        listOfText.add("1")
        listOfText.add("1")
        listOfText.add("1")
        listOfText.add("1")
        listOfText.add("1")
        listOfText.add("1")
        listOfText.add("1")
        listOfText.add("1")
        listOfText.add("1")
        listOfText.add("1")
        listOfText.add("1")
        listOfText.add("1")

        btenter = findViewById(R.id.bEnter) // initialize button
        etUsertext = findViewById(R.id.etMessage )// to get text from user

        myRV.adapter = RecyclerViewAdapter(listOfText)// pass list to adapter
        myRV.layoutManager = LinearLayoutManager(this)// fixed step

        btenter.setOnClickListener { addText() }
    }

    fun addText() {
        val text = etUsertext.text.toString()
        if (text.isNotEmpty()) {
            listOfText.add(text)
            etUsertext.text.clear()
            etUsertext.clearFocus()
            myRV.adapter?.notifyDataSetChanged() // to chick if add new things then update adapter
        }
        else {
            Snackbar.make(myRV,"Please enter some text", Snackbar.LENGTH_LONG).show() // snackbar
        }
    }

}