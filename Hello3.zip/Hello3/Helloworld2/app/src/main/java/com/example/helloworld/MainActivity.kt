package com.example.helloworld

import android.graphics.Color
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.RadioButton
import android.widget.TextView
import androidx.core.graphics.plus
import kotlin.random.Random

class MainActivity : AppCompatActivity() {

    lateinit var myText: TextView
    lateinit var myText1: TextView
    lateinit var myText2: TextView
    lateinit var myText3: TextView
    lateinit var myText4: TextView
    lateinit var myText5: TextView
    lateinit var  Button3: Button
    lateinit var  Button4: Button
   lateinit var textView2: TextView
   lateinit var userinput : EditText
   lateinit var RadioButton2: RadioButton
    var myList= mutableListOf<String>()

    //lateinit var color: Color
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        myText = findViewById<TextView>(R.id.tvMainText)
        myText1 = findViewById<TextView>(R.id.tvMainText1)
        myText2 = findViewById<TextView>(R.id.tvMainText2)
        myText3 = findViewById<TextView>(R.id.tvMainText3)
        myText4 = findViewById<TextView>(R.id.tvMainText4)
        myText5 = findViewById<TextView>(R.id.tvMainText5)
        Button3 = findViewById<Button>(R.id.button3)
        Button4 = findViewById<Button>(R.id.button4)
        userinput = findViewById<EditText>(R.id.input)
        textView2= findViewById<TextView>(R.id.textView2)
        RadioButton2=findViewById<RadioButton>(R.id.radioButton2)
        Button3.setOnClickListener { changeColor() }
        Button4.setOnClickListener { AddText() }

    }

    fun changeText(){
        myText.text="You are got it"
    }

    fun changeColor(){
        var myList= mutableListOf<Int>(0,0,0,0,0,0)
        var color=0
        for(i in 0..5){
            myList[i]= Color.argb(255,Random.nextInt(255)-i,Random.nextInt(255)-i,Random.nextInt(255)-i)

        }
if (RadioButton2.isChecked)
    changeText()
        else
    myText.text="wrong , the answer is (are)"

        myText.setTextColor(myList[0])
        myText1.setTextColor(myList[1])
        myText1.text="This is firts random color"
        myText2.setTextColor(myList[2])
        myText2.text="This is second random color"
        myText3.setTextColor(myList[3])
        myText3.text="This is third random color"
        myText4.setTextColor(myList[4])
        myText4.text="This is forth random color"
        myText5.setTextColor(myList[5])
        myText5.text="This is fifth random color"
    }

    fun AddText() {
        myList.add(userinput.text.toString())
        textView2.text="You Enter  ${userinput.text}"
        for(i in myList){
            Log.d("MainActivity","my list contain $i)")}
    }
}

        /*
        var num1 =1f
        var num2= 2f
        Log.d("MainActivity","The result of 1+2 = ${cal(num1,num2,'+')}")
        Log.d("MainActivity","The result of 1-2 = ${cal(num1,num2,'-')}")
        Log.d("MainActivity","The result of 1*2 = ${cal(num1,num2,'*')}")

        num2= 0f
        if(num2==0f)
            Log.d("MainActivity", "Can not divide by 0")
        else
            Log.d("MainActivity","The result of 1/2 = ${cal(num1,num2,'/')}")


    }

    fun cal(num1 :  Float , num2 :  Float , op : Char) : Float {
        when (op) {
            '+' -> return num1 + num2
            '-' -> return num1 - num2
            '*' -> return num1 * num2
            '/' -> return num1 / num2
        }
        return 0f
    }
}

         */