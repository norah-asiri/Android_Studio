package com.example.xmlparsingrssfeedhttpurlconnectionsasiri

import retrofit2.http.GET
import com.example.xmlparsingrssfeedhttpurlconnectionsasiri.model.Feed
import retrofit2.Call

// make api and use get
interface FeedAPI {
    @get:GET("dogs/.rss")
    val feed: Call<Feed?>?

    companion object {
        const val BASE_URL = "https://www.reddit.com/r/"
    }
}