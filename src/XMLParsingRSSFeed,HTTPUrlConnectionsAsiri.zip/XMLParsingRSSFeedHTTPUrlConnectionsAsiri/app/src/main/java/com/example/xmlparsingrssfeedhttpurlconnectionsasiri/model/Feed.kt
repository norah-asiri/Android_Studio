package com.example.xmlparsingrssfeedhttpurlconnectionsasiri.model

import com.example.xmlparsingrssfeedhttpurlconnectionsasiri.model.Entry.Entry
import org.simpleframework.xml.Element
import org.simpleframework.xml.ElementList
import org.simpleframework.xml.Root
import java.io.Serializable

// to get data we must do :
/*
1- create class Feed for first tag (feed) from this .rss url "https://www.reddit.com/r/dogs/.rss"
 */
@Root(name = "feed", strict = false)
class Feed constructor() : Serializable   {

    //2- for each tag we need to get it write 2 line:
    @field:Element(name = "icon") // a- get element name
    var icon: String? = null // b- declare var and name it and determine the type of data

    @field:Element(name = "id")
    var id: String? = null

    @field:Element(name = "logo")
    var logo: String? = null

    @field:Element(name = "title")
    var title: String? = null

    @field:Element(name = "updated")
    var updated: String? = null

    @field:Element(name = "subtitle")
    var subtitle: String? = null

    @field:ElementList(inline = true, name = "entry")
    var entrys: List<Entry>? = null // for list type , we defined separated class at model-> entry


}