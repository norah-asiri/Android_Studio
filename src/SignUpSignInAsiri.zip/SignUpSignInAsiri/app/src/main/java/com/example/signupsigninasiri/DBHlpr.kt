package com.example.signupsigninasiri


import android.annotation.SuppressLint
import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteException
import android.database.sqlite.SQLiteOpenHelper

// https://developer.android.com/reference/kotlin/android/database/sqlite/SQLiteDatabase
// https://www.codevoila.com/post/47/android-tutorial-sqlite-database

//(val id: Int, val name: String , val mobile: String, val location: String, val password: String )
class DBHlpr (context : Context ) :
SQLiteOpenHelper(context,"details.db",null,1 ) {

    var sqLiteDatabase: SQLiteDatabase = writableDatabase

    // here we create db class , then pass value from main
    override fun onCreate(db: SQLiteDatabase?) {
        if (db != null)


            db.execSQL("create table user (Name text , Location text, Mobile text, Password text)")
        // db.execSQL("create table tableName (column1 type , column2 type)")
    }

    override fun onUpgrade(db: SQLiteDatabase?, oldVersion: Int, newVersion: Int) {
    }

    fun addUser(s1:UserModel): Long {
        val cv = ContentValues()

        // add data to column
        cv.put("Name", s1.name)
        cv.put("Location", s1.location)
        cv.put("Mobile", s1.mobile)
        cv.put("Password", s1.password)


        var status = sqLiteDatabase.insert("user", null, cv)
        // add record to table
        // -1 = did not save data
        // row number  = data it save successfully
        return status
    }

    @SuppressLint("Range")
    fun retrive(phone: String, userPass:String): String {

        var c: Cursor = sqLiteDatabase.query(
            "user",
            null,
            "Mobile=?",
            arrayOf(phone),// value of hole row it is saving in c cursor
            null,
            null,
            null
        )

        if (c.count < 1) {
            return "name not exist"
        }
        // from db , table , column , give me value of row ()
        c.moveToFirst()
        var name = c.getString(c.getColumnIndex("Name"))
        var pass = c.getString(c.getColumnIndex("Password"))
        var loc = c.getString(c.getColumnIndex("Location"))

        if(userPass!= pass.toString()){
            return "Uncorrected password"
        }

        return "\n Welcome $name \n \n Yours details is: \n Phone: $phone \n Location: $loc"
    }

    fun updateLoc(s1: String, s2: String): Int {
        sqLiteDatabase = writableDatabase
        val cv = ContentValues()
        cv.put("Location", s2)
        var j = sqLiteDatabase.update("students", cv, "Name=?", arrayOf(s1))
        // update table students , set Location = s2 where name = s1
        return j
    }

    fun delName(userPhone: String) {
        sqLiteDatabase = writableDatabase
        sqLiteDatabase.delete("students", "Mobile=?", arrayOf(userPhone))
    }
}