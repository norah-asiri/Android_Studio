package com.example.signupsigninasiri

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast

class SignUp : AppCompatActivity() {

 private lateinit var etName : EditText
 private lateinit var etLoc : EditText
 private lateinit var etNum : EditText
 private lateinit var etPass : EditText
 private lateinit var btnSubmite : Button

 lateinit var db : DBHlpr


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_sign_up)

        db = DBHlpr(this)
        etName = findViewById(R.id.etName)
        etLoc = findViewById(R.id.etLoc)
        etNum = findViewById(R.id.etPhone)
        etPass = findViewById(R.id.etPassword)
        btnSubmite = findViewById(R.id.btnSubmite)

        btnSubmite.setOnClickListener {

            val userInfo= signup()
            val intent= Intent(this@SignUp,MainScreen::class.java)
            intent.putExtra("Info", "${userInfo}")
            startActivity(intent)


        }
    }
    // add user
    private fun signup() : String {
        val s= db.addUser(UserModel(0, etName.text.toString(),etLoc.text.toString(),etNum.text.toString(),etPass.text.toString()))
        println("${ etName.text},  ${etLoc.text},  ${ etNum.text },  ${etPass.text} ")
        //etName.text.clear()
        Toast.makeText(this, "User Added at $s", Toast.LENGTH_LONG).show()
       return db.retrive(etNum.text.toString(),etPass.text.toString())
    }
}