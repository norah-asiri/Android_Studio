package com.example.signupsigninasiri

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView

class MainScreen : AppCompatActivity() {
    lateinit var db : DBHlpr
    private lateinit var tvWelcome : TextView
    private lateinit var btnSignOut : Button


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main_screen)

        db = DBHlpr(this)
        val info= intent.getStringExtra("Info").toString()

        tvWelcome = findViewById(R.id.textView)
        btnSignOut = findViewById(R.id.SignOut)

        tvWelcome.text = info



    }
}