package com.example.signupsigninasiri

data class UserModel(val id: Int, val name: String, val location: String, val mobile: String, val password: String )
