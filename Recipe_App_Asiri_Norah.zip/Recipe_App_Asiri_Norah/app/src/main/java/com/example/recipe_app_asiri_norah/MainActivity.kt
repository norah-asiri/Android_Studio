package com.example.recipe_app_asiri_norah

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.app.ProgressDialog
import android.content.Intent
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class MainActivity : AppCompatActivity() {
   private lateinit var title : EditText
    private lateinit var author :EditText
    private lateinit var inge :EditText
    private lateinit var ins:  EditText
    private lateinit var savebtn : Button
    private lateinit var btnViewreceipe :Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // declare and initialize
        title = findViewById(R.id.etTitle)
        author = findViewById(R.id.etAuthor)
        inge = findViewById(R.id.etIngredients)
        ins = findViewById(R.id.etInstructions)
        savebtn = findViewById(R.id.btnSave)
        btnViewreceipe = findViewById(R.id.btnViewreceipe)


        // save the entered data :   Title , Author, Ingredients and Instructions
        savebtn.setOnClickListener {
            var f = RecipeDetails.Datum(title.text.toString(), author.text.toString(),
                inge.text.toString(),ins.text.toString())

            // save data at server if the connect done
            addReceipe(f, onResult = {
                title.setText("")
                author.setText("")
                inge.setText("")
                ins.setText("")
                Toast.makeText(applicationContext, "Save Success!", Toast.LENGTH_SHORT).show();
            })
        }
    }


    fun addReceipe(userData: RecipeDetails.Datum, onResult: (RecipeDetails?) -> Unit) {
        val apiInterface = APIClient().getClient()?.create(APIInterface::class.java)

        val progressDialog = ProgressDialog(this@MainActivity)
        progressDialog.setMessage("Please wait")
        progressDialog.show()

        if (apiInterface != null) {
            apiInterface.addRecipie(userData).enqueue(object : Callback<RecipeDetails> {
                override fun onResponse(
                    call: Call<RecipeDetails>,
                    response: Response<RecipeDetails>
                ) {
                    onResult(response.body())
                    progressDialog.dismiss()
                }

                override fun onFailure(call: Call<RecipeDetails>, t: Throwable) {
                    onResult(null)
                    Toast.makeText(applicationContext, "Error!", Toast.LENGTH_SHORT).show();
                    progressDialog.dismiss()

                }
            })
        }
    }

    // go to ViewRecipes activity to get data from server and show it
    fun viewreceipe(view: android.view.View) {
        intent = Intent(applicationContext, ViewRecipes::class.java)
        startActivity(intent)
    }
}