package com.example.a2in1appnorahasiri

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.main_menu, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            R.id.Numbers_Game -> {
                var intent = Intent(this, GNumber::class.java)
                startActivity(intent)

                return true
            }
            R.id.Guess_Phrase -> {
                var intent = Intent(this, GuessPharse::class.java)
                startActivity(intent)

                return true
            }
            R.id.Home -> {
                var intent = Intent(this, MainActivity::class.java)
                startActivity(intent)

                return true
            }
        }
        return super.onOptionsItemSelected(item)
    }

    override fun onPrepareOptionsMenu(menu: Menu?): Boolean {
        menu?.removeItem(R.id.Home)
        return super.onPrepareOptionsMenu(menu)
    }

    fun guessNamber(view: android.view.View) {
        var intent = Intent(this, GNumber::class.java)
        startActivity(intent)
    }

    fun phares(view: android.view.View) {
        var intent = Intent(this, GuessPharse::class.java)
        startActivity(intent)
    }
}
