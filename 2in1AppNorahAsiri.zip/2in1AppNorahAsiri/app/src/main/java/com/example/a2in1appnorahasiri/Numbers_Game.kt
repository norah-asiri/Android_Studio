package com.example.a2in1appnorahasiri
import android.app.Activity
import android.content.DialogInterface
import android.content.Intent
import android.content.pm.ActivityInfo
import android.content.pm.ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
import android.content.pm.ActivityInfo.SCREEN_ORIENTATION_USER_LANDSCAPE
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.android.material.snackbar.Snackbar
import kotlinx.android.synthetic.main.activity_guess_pharse.*
import kotlinx.android.synthetic.main.activity_main.*
import kotlin.random.Random

class Numbers_Game : AppCompatActivity() {


   // private lateinit var clMain: ConstraintLayout
    // android:screenOrientation="portrait"
    private lateinit var guessField: EditText
    private lateinit var butGuess: Button
    private lateinit var results: ArrayList<String>
    private var answer = 0
    private var guesses = 3
    //private  var text = ""


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_numbers_game)
        //requestedOrientation = SCREEN_ORIENTATION_USER_LANDSCAPE
        setContentView(R.layout.activity_main)
       // clMain = findViewById(R.id.clRoot)
        guessField = findViewById(R.id.etGuess)
        butGuess = findViewById(R.id.butGuess)

        answer = Random.nextInt(0,11)
        results = ArrayList()

        rvMessages.adapter = MessageAdapter(this, results)
        rvMessages.layoutManager = LinearLayoutManager(this)

        butGuess.setOnClickListener { addMessage() }
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.main_menu, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            R.id.Numbers_Game -> {
                var intent = Intent(this, Numbers_Game::class.java)
                startActivity(intent)

                return true
            }
            R.id.Guess_Phrase -> {
                var intent = Intent(this, GuessPharse::class.java)
                startActivity(intent)

                return true
            }
            R.id.Home -> {
                var intent = Intent(this, MainActivity::class.java)
                startActivity(intent)

                return true
            }
        }
        return super.onOptionsItemSelected(item)
    }

    override fun onPrepareOptionsMenu(menu: Menu?): Boolean {
        menu?.removeItem(R.id.Home)
        return super.onPrepareOptionsMenu(menu)
    }

    private fun addMessage() {
        val msg = guessField.text.toString()
        if (msg.isNotEmpty()) {
            if (guesses > 0) {
                if (msg.toInt() == answer) {
                    showAlertDialog("You Got it! \n\nPlay again?") }
                else {
                    results.add("You guessed $msg")
                    guesses--
                    results.add("You have $guesses chance left")
                    //  text+="\n"
                }
                if (guesses == 0) {
                    results.add("Lose the game, The correct answer was $answer")
                    results.add("Game Over")
                    showAlertDialog(" Lose the game. The correct answer was $answer.\n Play again?")

                }
            }
            guessField.text.clear()
            guessField.clearFocus()
            rvMessages.adapter?.notifyDataSetChanged()
        } else {
          //  Toast.makeText(applicationContext ,"Please enter a number" ,Toast.LENGTH_LONG ).show()
           // Snackbar.make(clMain, "Please enter a number", Snackbar.LENGTH_LONG).show()
        }
    }
    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        // results[guesses]= guessField.toString()
        outState.putInt("myNumber",guesses )
        //results.add(text)
        outState.putStringArrayList("myMessage",results)
    }

    override fun onRestoreInstanceState(savedInstanceState: Bundle) {
        super.onRestoreInstanceState(savedInstanceState)
        guesses= savedInstanceState.getInt("myNumber", 0)
        results.add(savedInstanceState.getString("myMessage", "No message"))

    }


    private fun showAlertDialog(title: String) {
        // build alert dialog
        val dialogBuilder = AlertDialog.Builder(this)

        // set message of alert dialog
        dialogBuilder.setMessage(title)
            // if the dialog is cancelable
            .setCancelable(false)
            // positive button text and action
            .setPositiveButton("Yes", DialogInterface.OnClickListener { dialog, id ->
                this.recreate()
            })
            // negative button text and action
            .setNegativeButton("No", DialogInterface.OnClickListener { dialog, id ->
                dialog.cancel()
                finishAffinity()
            })

        // create dialog box
        val alert = dialogBuilder.create()
        // set title for alert dialog box
        alert.setTitle("Game Over")
        // show alert dialog
        alert.show()
    }
}
