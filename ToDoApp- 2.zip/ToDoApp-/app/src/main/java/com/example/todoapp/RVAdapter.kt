package com.example.todoapp

import android.graphics.Color
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.todoapp.databinding.ItemRowBinding

class RVAdapter(private val items: ArrayList<ToDoItem>): RecyclerView.Adapter<RVAdapter.ItemViewHolder>() {
    class ItemViewHolder(val binding: ItemRowBinding): RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ItemViewHolder {
        return ItemViewHolder(
            ItemRowBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        )
    }

    override fun onBindViewHolder(holder: ItemViewHolder, position: Int) {
        val item = items[position]

        holder.binding.apply {
            tvItem.text = item.text // text that will be appear behind check box
            cbItem.isChecked = item.checked // checkBox item
            cbItem.setOnCheckedChangeListener { _, isChecked ->
                if(isChecked){ // change text color
                    tvItem.setTextColor(Color.GRAY)
                }else{
                    tvItem.setTextColor(Color.BLACK)
                }
                item.checked = !item.checked
            }
        }
    }

    override fun getItemCount() = items.size

    fun deleteItems(){ // new fun for delete item
        items.removeAll{ item -> item.checked } // delete selected item
        notifyDataSetChanged() // update rv
    }

}