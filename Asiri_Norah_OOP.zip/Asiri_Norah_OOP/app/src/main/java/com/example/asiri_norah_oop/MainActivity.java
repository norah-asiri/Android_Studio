package com.example.asiri_norah_oop;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        classDog[] dogs = {new classDog("Rufus"),new classDog("Fred") ,
                new classDog("Spot") ,new classDog("Max") ,new classDog("Cody")};

        classCat[] cats = {new classCat("Lili"),new classCat("Furball") ,
                new classCat("Snowball") ,new classCat("Meep") ,new classCat("Patchy")};


// if they are older than the meowing cat

        for(int i =0; i<cats.length; i++)
        {
            cats[i].meow_function();

            for(int j =0; j<dogs.length; j++){
              if(dogs[j].age > cats[i].age)
                  dogs[j].bark_function();
            }

        }
    }

}

/* Create a list of five dogs and a list of five cats with random ages
Use a loop to iterate through the list of cats and make each cat meow,
 also use a nested loop to make each dog bark if they are older than the meowing cat

Print everything to the console

 */
