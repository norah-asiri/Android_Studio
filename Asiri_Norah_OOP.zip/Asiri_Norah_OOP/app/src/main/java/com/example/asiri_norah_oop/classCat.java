package com.example.asiri_norah_oop;

public class classCat {
    String name;
    int age;
    int randomNum = 1 + (int)(Math.random() * 10);

    //The class should also have a meow function that prints 'name of cat: Meow'
public classCat(String name){
  this.age=randomNum;
  this.name= name;
}
    void meow_function(){
        System.out.println("name of cat: "+ name );
        // System.out.println("name of cat: "+ name +" Age is: "+ age );
    }
}
