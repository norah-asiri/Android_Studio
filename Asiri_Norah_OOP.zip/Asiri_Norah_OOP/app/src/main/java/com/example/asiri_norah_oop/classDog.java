package com.example.asiri_norah_oop;

public class classDog {
    String name;
    int age;
// // ages[new Random().nextInt(ages.length)
    int randomNum = 1 + (int)(Math.random() * 10);

    public classDog(String name){
        this.age = randomNum;
        this.name= name;
    }

    //have a bark function that prints 'name of dog: Woof'
    void bark_function(){
        System.out.println("name of dog: "+ name  );
    }

}
