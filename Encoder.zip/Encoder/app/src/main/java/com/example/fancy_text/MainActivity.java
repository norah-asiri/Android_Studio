package com.example.fancy_text;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    String userInput="";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
    public void buGetText(View view) {
            EditText editText =(EditText)findViewById(R.id.editText);
            TextView textView2 =(TextView)findViewById(R.id.textView2);
            userInput = editText.getText().toString();
            String LowerUpperUserInput = "";
            char letter;
            //Nou ra
             int j=0;
            for(int i=0; i <userInput.length(); i++){
                letter = userInput.charAt(i);
                if(j%2==0 && Character.isAlphabetic(letter)) {
                    letter = userInput.toUpperCase().charAt(i);
                    j++;
                } else {
                    if (j % 2 != 0 && Character.isAlphabetic(letter)) {
                        letter = userInput.toLowerCase().charAt(i);
                        j++;
                    } }
                LowerUpperUserInput= LowerUpperUserInput + letter; }
            System.out.println(LowerUpperUserInput);
            // Toast.makeText(this,LowerUpperUserInput,Toast.LENGTH_LONG).show();
            textView2.setText(LowerUpperUserInput);
        } }
