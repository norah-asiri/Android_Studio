package com.example.notificationsappasiri

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.graphics.BitmapFactory
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import com.example.notificationsappasiri.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    lateinit var notificationManager: NotificationManager
    lateinit var notificationChannel: NotificationChannel
    lateinit var builder: Notification.Builder
    private val notificationId = 123
    private val channelId = "myapp.notifications"
    private val description = "Here Notification App, created by Asiri"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        /*
        add to gradle file

        buildFeatures{
        viewBinding = true }
         */
        val binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        //setting the notification manager
        notificationManager = getSystemService(NOTIFICATION_SERVICE) as NotificationManager


        binding.btnNotification.setOnClickListener{
            if (binding.etNotification.text.isNotEmpty()){

            //creating intent of the next activity
            val intent = Intent(this, NatActivity::class.java)

            //creating a pending intent of the intent we created before, in case the user clicked on the notification
            //the pending intent will be waiting until the user clicks on the notification.
            val pendingIntent = PendingIntent.getActivity(this, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT)

            //creating a notification channel for the notification.
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                notificationChannel = NotificationChannel(channelId, description,
                    NotificationManager.IMPORTANCE_HIGH)
                notificationManager.createNotificationChannel(notificationChannel)

                //building the notification
                builder = Notification.Builder(this, channelId)
                    .setSmallIcon(R.drawable.ic_baseline_notifications_24)
                    .setLargeIcon(BitmapFactory.decodeResource(this.resources, R.drawable.ic_baseline_notifications_24))// convert image to .pmp
                    .setContentIntent(pendingIntent)
                    .setContentTitle("My Notification")
                    .setContentText(binding.etNotification.text!!)
            } else {
                // Bitmap pmp=BitmapFactory.

                // building the notification
                builder = Notification.Builder(this)
                    .setSmallIcon(R.drawable.ic_baseline_notifications_24)// set small notification icon
                    .setLargeIcon(BitmapFactory.decodeResource(this.resources, R.drawable.ic_baseline_notifications_24)) // set large notification icon -> imag.pmp
                    .setContentIntent(pendingIntent)
                    .setContentTitle("My Notification") //// set title notification icon
                    .setContentText(binding.etNotification.text!!) // // set content notification icon
            }
            //executing the notification
            notificationManager.notify(notificationId, builder.build())

            }else{
                Toast.makeText(this@MainActivity, "Can not create empty notification", Toast.LENGTH_LONG).show()
            }

        }

    }
}