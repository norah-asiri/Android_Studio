package com.example.basic_app

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView

class A_2 : AppCompatActivity() {
    lateinit var info : TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_a2)
        val information=intent.extras?.get("UserInformation")
        info=findViewById(R.id.textView2)
        info.text=information.toString()

    }
}