package com.example.basic_app

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast



class MainActivity : AppCompatActivity() {

    lateinit var print_b : Button
    lateinit var next_b : Button
    lateinit var toast_b : Button
    lateinit var name_u : TextView
    lateinit var mobile_u : TextView
    lateinit var location_usee : TextView
    lateinit var print_user_info: TextView


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        toast_b=findViewById(R.id.button)
        print_b=findViewById(R.id.button2)
        next_b=findViewById(R.id.button3)
        name_u = findViewById(R.id.Name)
        location_usee=findViewById(R.id.Location)
        mobile_u=findViewById(R.id.Number)
        print_user_info=findViewById(R.id.print_user_info)

        var information = listOf(name_u.text,location_usee.text,mobile_u.text)

        next_b.setOnClickListener {
            intent= Intent(this,A_2::class.java)
            intent.putExtra("UserInformation",information.shuffled().toString())
            startActivity(intent)

        }
        print_b.setOnClickListener {
            print_user_info.text= information.toString() }

        toast_b.setOnClickListener {
            Toast.makeText(this@MainActivity, information.shuffled().take(1).toString(), Toast.LENGTH_SHORT).show()
        }



    }
}