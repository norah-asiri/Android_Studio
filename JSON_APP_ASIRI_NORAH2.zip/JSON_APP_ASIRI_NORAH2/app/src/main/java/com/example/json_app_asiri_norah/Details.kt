package com.example.json_app_asiri_norah

import com.google.gson.annotations.SerializedName

    class Datum {
    @SerializedName("date")
    var date: String? = null

    @SerializedName("eur")
    var eur: Cur? = null

    class Cur {
        @SerializedName("ada")
        var ada: String? = null

        @SerializedName("afn")
        var afn: String? = null

        @SerializedName("all")
        var all: String? = null



    }
}