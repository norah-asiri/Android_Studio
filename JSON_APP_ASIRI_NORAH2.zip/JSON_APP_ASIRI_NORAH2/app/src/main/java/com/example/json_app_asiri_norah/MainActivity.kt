package com.example.json_app_asiri_norah


import java.text.ParsePosition
import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.example.json_app_asiri_norah.APIClient
import com.example.json_app_asiri_norah.APIInterface
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class MainActivity : AppCompatActivity() {
    lateinit var  spinner : Spinner
    var c =""
    var selected: String =""
    var selected1: Int =0
    private lateinit var  bt : Button
    lateinit var tvResult: TextView
    lateinit var tvC: TextView
    lateinit var et: EditText
    var sel =0.0
    var currency =0.0
    private var Details: Datum? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        spinner = findViewById(R.id.spinner)
        tvResult= findViewById(R.id.tvResult)
        bt= findViewById(R.id.bt)
        tvC= findViewById(R.id.textView)
        et = findViewById(R.id.et)

        val cur = arrayListOf("all", "ada", "afn")

       // tvResult.text= c
        setUpSpinner()

        bt.setOnClickListener {
            currency = tvC.text.toString().toDouble()
            //currency= sel

        }

    }

    fun setUpSpinner(){

        // هذا الادبتر عشان يضبط عرض العناصر في القائمة المنسدلة
        // نحتاج أدبتر من نوع ارري (ذس للأكتفيتي , الثاني نربطه بالارري الي كتبنا عناصرها بملف الاسترينق , الثالث نربطه بملف الايوت الي نسقنا فيه القائمة زي مانبغى)
        val adapter = ArrayAdapter.createFromResource(this,R.array.Euro , R.layout.txt_spr)
        // نربط الادبتر تبع الاسبنر
        adapter.setDropDownViewResource(R.layout.txt_spr)
        spinner.adapter=adapter
        spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener{
            override fun onItemSelected(parent: AdapterView<*>?, view: View?,position : Int, id: Long) {
                c= parent!!.getItemAtPosition(position).toString()

                when (position) {
                    0 -> tvResult.text = cal(Details?.eur?.all?.toDouble(), currency).toString()
                    1 -> tvResult.text = cal(Details?.eur?.ada?.toDouble(), currency).toString()
                    2 -> tvResult.text = cal(Details?.eur?.afn?.toDouble(), currency).toString()


                }
            }

            override fun onNothingSelected(p0: AdapterView<*>?) {

            }

        }
    }

    fun cal (x : Double?, y: Double): Double{
        var result = y * x!!
        return result


    }


}
