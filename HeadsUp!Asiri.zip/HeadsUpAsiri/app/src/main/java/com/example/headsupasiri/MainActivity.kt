package com.example.headsupasiri

import android.app.ProgressDialog
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.headsupasiri.model.Celebrity
import kotlinx.android.synthetic.main.item_row.*
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response


class MainActivity : AppCompatActivity() {

    private lateinit var rvMain: RecyclerView
    private lateinit var rvAdapter: Adapter
    private val apiInterface by lazy { APIClient().getClient().create(APIInterface::class.java) }
    private lateinit var progressDialog: ProgressDialog
    private lateinit var btAdd: Button
    private lateinit var etCelebrity:EditText
    private lateinit var btDetails: Button
    private lateinit var celebrities: ArrayList<Celebrity>

    /*
    var pk = 0
    var Updatepk = ""
    var f = false
    private lateinit var rvMain: LinearLayout
    lateinit var Name : TextView
    lateinit var  myRV : RecyclerView
    //lateinit var tvMessage: TextView
    private lateinit var playerList : ArrayList<String>
    private lateinit var info :  ArrayList<Celebrity>
    private val apiInterface by lazy { APIClient().getClient().create(APIInterface::class.java) }

     */

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
     //   ActivityMainBinding binding = DataBindingUtil.setContentView(this, R.layout.activity_main)
        celebrities = arrayListOf()

        rvMain = findViewById(R.id.myRV)
        rvAdapter = Adapter(celebrities)
        rvMain.adapter = rvAdapter
        rvMain.layoutManager = LinearLayoutManager(this)
        btAdd = findViewById(R.id.btAdd)

        btAdd.setOnClickListener {
            intent = Intent(applicationContext, AddNewCelebrity::class.java)
            val celebrityNames = arrayListOf<String>()
            for(c in celebrities){
                celebrityNames.add(c.name.lowercase())
            }
            intent.putExtra("celebrityNames", celebrityNames)
            startActivity(intent)
        }

        etCelebrity = findViewById(R.id.etCelebrity)
        btDetails = findViewById(R.id.btDetails)
        btDetails.setOnClickListener {

            if(etCelebrity.text.isNotEmpty()){
                updateCelebrity()
            }else{
                Toast.makeText(this, "Please enter a name", Toast.LENGTH_LONG).show()
            }
        }

        progressDialog = ProgressDialog(this)
        progressDialog.setMessage("Please Wait")
        progressDialog.show()

        getCelebrities()
    }

    private fun getCelebrities(){
        apiInterface.getCelebrities().enqueue(object: Callback<ArrayList<Celebrity>>{
            override fun onResponse(
                call: Call<ArrayList<Celebrity>>,
                response: Response<ArrayList<Celebrity>>
            ) {
                progressDialog.dismiss()
                celebrities = response.body()!!
                rvAdapter.update(celebrities)
            }

            override fun onFailure(call: Call<ArrayList<Celebrity>>, t: Throwable) {
                progressDialog.dismiss()
                Toast.makeText(this@MainActivity, "Unable to get data", Toast.LENGTH_LONG).show()
            }
        })
    }

    private fun updateCelebrity(){
        var celebrityID = 0
        for(celebrity in celebrities){
            if(etCelebrity.text.toString().capitalize() == celebrity.name){
                celebrityID = celebrity.pk
                intent = Intent(applicationContext, UpdateDeleteCelebrity::class.java)
                intent.putExtra("celebrityID", celebrityID)
                startActivity(intent)
            }else{
                Toast.makeText(this, "${etCelebrity.text.toString().capitalize()} not found", Toast.LENGTH_LONG).show()
            }
        }
    }
}

/*
        rvMain = findViewById(R.id.clRoot)
        playerList = ArrayList()
        info = ArrayList()
        myRV=findViewById(R.id.myRV)
     //   tvMessage=findViewById(R.id.Message)

        myRV.adapter = Adapter(playerList)
        myRV.layoutManager = LinearLayoutManager(applicationContext)
         Name = findViewById<View>(R.id.editTextTextPersonName) as TextView
        val Add = findViewById<View>(R.id.button2) as Button
        val udtate_sumit = findViewById<View>(R.id.button3) as Button
        Get(false)

        Add.setOnClickListener {
            Get(false)
            intent = Intent(this@MainActivity, AddNewCelebrity::class.java)
            startActivity(intent)
        }

        udtate_sumit.setOnClickListener {
            f =true
            Get(f)
                 println("________________ $pk , <<<<<< $Updatepk")
                intent = Intent(this@MainActivity, UpdateDeleteCelebrity::class.java)
                intent.putExtra("Updatepk", Updatepk)
                startActivity(intent)
                intent.putExtra("name","${Name.text}")
                println("Updatepk $Updatepk ,,,,,,,,, name $Name")

        }

    }

    fun Get(f : Boolean) {


        val apiInterface = APIClient().getClient()?.create(APIInterface::class.java)
        val progressDialog = ProgressDialog(this@MainActivity)
        progressDialog.setMessage("Please wait")
        progressDialog.show()
        if (apiInterface != null) {
            apiInterface.getUser()?.enqueue(object : Callback<List<Users.UserDetails>> {

                override fun onResponse(
                    call: Call<List<Users.UserDetails>>,
                    response: Response<List<Users.UserDetails>>
                ) {
                    progressDialog.dismiss()
                    var NewPost: String? = ""
                    for (User in response.body()!!) {
                        if (f == true){
                            if (User.name.toString() == Name.text.toString()){
                                println("****  ${User.name.toString().lowercase()}== ${Name.text.toString().lowercase()} *** ")
                             //  info.add(User.pk.toString())
                              // info.add(User.name.toString() )
                               // User.taboo1?.let { info.add(it) }
                              //  User.taboo2?.let { info.add(it) }
                              //  User.taboo3?.let { info.add(it) }

                                   Updatepk ="${User.pk}"
                                println("???? ${Updatepk}== ${User.pk!!} ???????")
                          NewPost =
                              NewPost + User.pk + "\n" + User.name + "\n" + User.taboo1 + "\n" + User.taboo2 + "\n" + User.taboo3 + "\n" + "\n"
                            break
                        }}

                        NewPost =
                            NewPost + User.pk + "\n" + User.name + "\n" + User.taboo1 + "\n" + User.taboo2 + "\n" + User.taboo3 + "\n" + "\n"

                    }
                    //      responseText.text = NewPost
                    NewPost?.let { playerList.add(it) }
                    myRV.adapter?.notifyDataSetChanged()
                }

                override fun onFailure(call: Call<List<Users.UserDetails>>, t: Throwable) {
                    progressDialog.dismiss()
                    Toast.makeText(applicationContext, "" + t.message, Toast.LENGTH_SHORT)
                        .show()
                }
            })
        }
    }}

 */