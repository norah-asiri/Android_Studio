package com.example.headsupasiri

import android.app.ProgressDialog
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import com.example.headsupasiri.model.Celebrity
private val apiInterface by lazy { APIClient().getClient().create(APIInterface::class.java) }
private lateinit var progressDialog: ProgressDialog
private lateinit var existingCelebrities: ArrayList<String>


class AddNewCelebrity : AppCompatActivity() {

   private lateinit var name : EditText
    private lateinit var taboo1: EditText
    private lateinit var taboo2 : EditText
    private lateinit var taboo3 : EditText
    private lateinit var add : Button
    private lateinit var back : Button

    var i =0
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_new_celebrity)

        taboo1 = findViewById(R.id.etNewTaboo1)
        taboo2 = findViewById(R.id.etNewTaboo2)
        taboo3 = findViewById(R.id.etNewTaboo3)
        add = findViewById(R.id.btnAdd)
        back = findViewById(R.id.btnBack)
        name = findViewById(R.id.etNewName)


        existingCelebrities = intent.extras!!.getStringArrayList("celebrityNames")!!

        add.setOnClickListener {
            /*
            var f = Users.UserDetails( name.text.toString(), taboo1.text.toString(), taboo2.text.toString(), taboo3.text.toString(),)
            addSingleuser(f, onResult = {
                name.setText("")
                taboo1.setText("")
                taboo2.setText("")
                taboo3.setText("")
                Toast.makeText(applicationContext, "Save Success!", Toast.LENGTH_SHORT).show() })
        }

             */
            if (name.text.isNotEmpty() && taboo1.text.isNotEmpty() &&
                taboo2.text.isNotEmpty() && taboo3.text.isNotEmpty()
            ) {
                addCelebrity() // fun
            } else {
                Toast.makeText(this, "One or more fields is empty", Toast.LENGTH_LONG).show()
            }
        }
    }
        private fun addCelebrity(){
            progressDialog = ProgressDialog(this)
            progressDialog.setMessage("Please Wait")
            progressDialog.show()

            apiInterface.addCelebrity(
                Celebrity(
                    // This only takes care of the first name
                    // If Michael Jordan exists, Michael jordan can still be added
                    // Can you find a way to fix this?
                    name.text.toString().capitalize(),
                    taboo1.text.toString(),
                    taboo2.text.toString(),
                    taboo3.text.toString(),
                    0
                )
            ).enqueue(object: Callback<Celebrity> {
                override fun onResponse(call: Call<Celebrity>, response: Response<Celebrity>) {
                    progressDialog.dismiss()
                    if(!existingCelebrities.contains(name.text.toString().lowercase())){
                        intent = Intent(applicationContext, MainActivity::class.java)
                        startActivity(intent)
                    }else{
                        Toast.makeText(this@AddNewCelebrity, "Celebrity Already Exists", Toast.LENGTH_LONG).show()
                    }
                }

                override fun onFailure(call: Call<Celebrity>, t: Throwable) {
                    progressDialog.dismiss()
                    Toast.makeText(this@AddNewCelebrity, "Unable to get data", Toast.LENGTH_LONG).show()
                }
            })
        }


 /*
    private fun addSingleuser(f: Users.UserDetails, onResult: () -> Unit) {

        val apiInterface = APIClient().getClient()?.create(APIInterface::class.java)
        val progressDialog = ProgressDialog(this@AddNewCelebrity)
        progressDialog.setMessage("Please wait")
        progressDialog.show()

        if (apiInterface != null) {
            apiInterface.addUser(f).enqueue(object : Callback<Users.UserDetails> {
                override fun onResponse(
                    call: Call<Users.UserDetails>,
                    response: Response<Users.UserDetails>) {
                    onResult()
                    progressDialog.dismiss()
                }

                override fun onFailure(call: Call<Users.UserDetails>, t: Throwable) {
                    onResult()
                    Toast.makeText(applicationContext, "Error!", Toast.LENGTH_SHORT).show();
                    progressDialog.dismiss() } })
        }
    }
        */

    fun addnew(view: android.view.View) {
        intent = Intent(applicationContext, AddNewCelebrity::class.java)
        startActivity(intent) }

    fun back(view: android.view.View) {
        intent = Intent(applicationContext, MainActivity::class.java)
        startActivity(intent) }
}