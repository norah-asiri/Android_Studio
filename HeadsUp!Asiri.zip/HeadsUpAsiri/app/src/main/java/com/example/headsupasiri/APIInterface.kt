package com.example.headsupasiri

import com.example.headsupasiri.model.Celebrity
import retrofit2.Call
import retrofit2.http.*

//https://dojo-recipes.herokuapp.com/celebrities/

interface APIInterface {
    @GET("/celebrities/")
    fun getCelebrities(): Call<ArrayList<Celebrity>>

    @POST("/celebrities/")
    fun addCelebrity(@Body celebrityData: Celebrity): Call<Celebrity>

    @GET("/celebrities/{id}")
    fun getCelebrity(@Path("id") id: Int): Call<Celebrity>

    // PUT replaces the full object (use PATCH to change individual fields)
    @PUT("/celebrities/{id}")
    fun updateCelebrity(@Path("id") id: Int, @Body celebrityData: Celebrity): Call<Celebrity>

    @DELETE("/celebrities/{id}")
    fun deleteCelebrity(@Path("id") id: Int): Call<Void>
}
/*
interface APIInterface {
    @Headers("Content-Type: application/json")
    @GET("celebrities/")
    fun getUser(): Call<List<Users.UserDetails>>

    @Headers("Content-Type: application/json")
    @GET("celebrities/{id}")
    fun getOneUser(@Path("id") id: Int, @Body userData: Users.UserDetails): Call<Users.UserDetails>

    @Headers("Content-Type: application/json")
    @POST("celebrities/")
    fun addUser(@Body userData: Users.UserDetails): Call<Users.UserDetails>

    @Headers("Content-Type: application/json")
    @PUT("celebrities/{id}")
    fun updateUser(@Path("id") id: Int, @Body userData: Users.UserDetails): Call<Users.UserDetails>

    @Headers("Content-Type: application/json")
    @DELETE("celebrities/{id}")
    fun deleteUser(@Path("id") id: Int): Call<Void>

}

 */
